package ejercicios;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class r4_restricción_llevar {

	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int vdorsal, vnetapa;
		String vcodigo, vnombre, vtipo;

		// Realizamos la conexión
		try {
			Properties propiedades = new Properties();
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado");

			// Interfaz: datos de entrada
			Scanner tec = new Scanner(System.in);
			System.out.println("Dorsal del ciclista:");
			vdorsal = Integer.parseInt(tec.nextLine());
			System.out.println("Número de etapa:");
			vnetapa = Integer.parseInt(tec.nextLine());
			System.out.println("Código del maillot (MGE, MMO, ...):");
			vcodigo = tec.nextLine().trim().toUpperCase();

			// Restricción 1a: el ciclista existe
			sql = "SELECT nombre FROM ciclista WHERE dorsal = ?";
			pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			pstmt.setInt(1, vdorsal);
			rs = pstmt.executeQuery();
			if (!rs.first()) {
				System.out.println("No existe ningún ciclista con dorsal " + vdorsal);
				return; // el finally cierra la conexión igualmente
			}
			vnombre = rs.getString("nombre");
			rs.close();
			pstmt.close();

			// Restricción 1b: la etapa existe
			sql = "SELECT netapa FROM etapa WHERE netapa = ?";
			pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			pstmt.setInt(1, vnetapa);
			rs = pstmt.executeQuery();
			if (!rs.first()) {
				System.out.println("No existe la etapa " + vnetapa);
				return;
			}
			rs.close();
			pstmt.close();

			// Restricción 1c: el maillot existe
			sql = "SELECT tipo FROM maillot WHERE codigo = ?";
			pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			pstmt.setString(1, vcodigo);
			rs = pstmt.executeQuery();
			if (!rs.first()) {
				System.out.println("No existe ningún maillot con código " + vcodigo);
				return;
			}
			vtipo = rs.getString("tipo");
			rs.close();
			pstmt.close();

			// Restricción 2: ese maillot no lo lleva ya otro ciclista en la etapa
			// (evitamos el error de clave duplicada PK(netapa, codigo) y decimos quién lo lleva)
			sql = "SELECT c.dorsal, c.nombre FROM llevar l JOIN ciclista c ON l.dorsal = c.dorsal "
					+ "WHERE l.netapa = ? AND l.codigo = ?";
			pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			pstmt.setInt(1, vnetapa);
			pstmt.setString(2, vcodigo);
			rs = pstmt.executeQuery();
			if (rs.first()) {
				if (rs.getInt("dorsal") == vdorsal)
					System.out.println(vnombre + " ya lleva el maillot " + vtipo
							+ " en la etapa " + vnetapa);
				else
					System.out.println("No se puede asignar: el maillot " + vtipo + " de la etapa "
							+ vnetapa + " ya lo lleva " + rs.getString("nombre")
							+ " (dorsal " + rs.getInt("dorsal") + ")");
				return;
			}
			rs.close();
			pstmt.close();

			// Restricción 3: el ciclista no lleva ya otro maillot en esa etapa
			sql = "SELECT m.codigo, m.tipo FROM llevar l JOIN maillot m ON l.codigo = m.codigo "
					+ "WHERE l.dorsal = ? AND l.netapa = ?";
			pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			pstmt.setInt(1, vdorsal);
			pstmt.setInt(2, vnetapa);
			rs = pstmt.executeQuery();
			if (rs.first()) {
				System.out.println("No se puede asignar: " + vnombre + " ya lleva el maillot "
						+ rs.getString("tipo") + " (" + rs.getString("codigo")
						+ ") en la etapa " + vnetapa);
				return;
			}
			rs.close();
			pstmt.close();

			// Se cumplen todas las restricciones: insertamos
			sql = "INSERT INTO llevar (dorsal, netapa, codigo) VALUES (?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, vdorsal);
			pstmt.setInt(2, vnetapa);
			pstmt.setString(3, vcodigo);

			int filas = pstmt.executeUpdate();
			if (filas == 1)
				System.out.println("Asignado: " + vnombre + " lleva el maillot " + vtipo
						+ " en la etapa " + vnetapa);
			else
				System.out.println("No se ha podido asignar el maillot");

		} catch (NumberFormatException e) {
			System.out.println("Dorsal y número de etapa deben ser números enteros");
		} catch (SQLException e) {
			System.out.println("Error de base de datos: " + e.getMessage());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Cerramos recursos y conexión
			try {
				if (rs != null && !rs.isClosed())
					rs.close();
				if (pstmt != null && !pstmt.isClosed())
					pstmt.close();
				if (con != null && !con.isClosed())
					con.close();
				System.out.println("Desconectado");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}