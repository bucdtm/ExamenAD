package ejercicios;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class Exem04_PreparedStatement_Select {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con = null; 
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql=null;
		//Obtener el numero de la etapa, y el nombre del ciclista, de las
		//etapas ganadas por el el dorsal que introduzca el usuario
		Scanner tec=new Scanner (System.in);	
		System.out.println("Introudce el dorsal:");
		Integer vdorsal=tec.nextInt();
		tec.nextLine();
		//Realizamos la conexion
		try {   
			Properties propiedades = new Properties();  
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado"); 	
		// operaciones BD
			sql=" select netapa, nombre "
					+ "from ciclista c join etapa e on c.dorsal=e.dorsal "
					+ "where c.dorsal=?";
		// Crear PreparedStament
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, vdorsal);
			rs=pstmt.executeQuery();
		//Recuperar la informaci�n en el resultSet
			while(rs.next())
			{System.out.println("numero etapa:"+rs.getString("netapa"));
			System.out.println("nombre"+ rs.getString(2));}		
			//Mostrar al usuario		
	} catch (SQLException e){
			e.printStackTrace();  
	} catch (FileNotFoundException e) {
			e.printStackTrace();
	}catch (IOException e) {
			e.printStackTrace();
	}catch (Exception e) {
			e.printStackTrace();
	}
	finally{
		//Cerramos la conexi�n
		try{ if(con!=null && !con.isClosed())      
			con.close();      
		System.out.println("Desconectado");          
	} catch(SQLException e)
		{            
			e.printStackTrace();       
		}      
	}
	}


}
