package ejercicios;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class Ex02_PreparedStatement_Select {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con = null; 
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql=null;
		//Realizamos la conexión
		try {   
			Properties propiedades = new Properties();  
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado"); 
		//Obtener el nombre de los ciclistas que han ganado puertos de la categoria que indica el usuario
			// Obtener la informaci�n del usuario - interfaz
			Scanner tec=new Scanner (System.in);	
			System.out.println("Introudce la categoria:");
			String vcategoria=tec.nextLine();
		// operaciones BD
			sql=" Select distinct nombre from ciclista join puerto on ciclista.dorsal=puerto.dorsal"
					+ " where categoria=?";
	
			// Crear PreparedStament
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, vcategoria);
			rs=pstmt.executeQuery();
		//Recuperar la informaci�n en el resultSet
			while(rs.next())
			{System.out.println(rs.getString(1));}		
			//Mostrar al usuario		
	} catch (SQLException e){
			e.printStackTrace();  
	} catch (FileNotFoundException e) {
			e.printStackTrace();
	}catch (IOException e) {
			e.printStackTrace();
	}catch (Exception e) {
			e.printStackTrace();
	}
	finally{
		//Cerramos la conexi�n
		try{ if(con!=null && !con.isClosed())      
			con.close();      
		System.out.println("Desconectado");          
	} catch(SQLException e)
		{            
			e.printStackTrace();       
		}      
	}
	}


}
