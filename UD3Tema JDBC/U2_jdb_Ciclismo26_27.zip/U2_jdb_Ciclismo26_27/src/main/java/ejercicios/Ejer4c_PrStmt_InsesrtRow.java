package ejercicios;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class Ejer4c_PrStmt_InsesrtRow {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con = null; 
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql=null;
		//Realizamos la conexi�n
		try {   
			Properties propiedades = new Properties();  
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado"); 
			
			//Insertar un nuevo equipo CicliValencia
			
			sql="select * from equipo";
				
			pstmt=con.prepareStatement(sql, 
					ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs=pstmt.executeQuery(sql);
			// obtener la posici�n del resultSet en la que voy a insertar
			
			rs.moveToInsertRow();
			rs.updateString(1,"CicliValecia2");
			rs.updateString(2, " Luisito el listo");
			rs.insertRow();
			
			
			//Mostrar al usuario		
	} catch (SQLException e){
			e.printStackTrace();  
	} catch (FileNotFoundException e) {
			e.printStackTrace();
	}catch (IOException e) {
			e.printStackTrace();
	}catch (Exception e) {
			e.printStackTrace();
	}
	finally{
		//Cerramos la conexi�n
		try{ if(con!=null && !con.isClosed())      
			con.close();      
		System.out.println("Desconectado");          
	} catch(SQLException e)
		{            
			e.printStackTrace();       
		}      
	}
	}
}
