package ejercicios;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class ex05_Insert_etapa_restriccion {

	static final int KM_MIN = 100;
	static final int KM_MAX = 300;
	static final int KM_TOTAL_MAX = 1500;

	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Integer vnetapa, vkm, vtotal;
		String vsalida, vllegada;
		Integer vdorsal;

		// Realizamos la conexión
		try {
			Properties propiedades = new Properties();
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado");

			// Interfaz: datos de entrada de la nueva etapa
			Scanner tec = new Scanner(System.in);
			System.out.println("Número de etapa:");
			vnetapa = Integer.parseInt(tec.nextLine());
			System.out.println("Kilómetros:");
			vkm = Integer.parseInt(tec.nextLine());
			System.out.println("Ciudad de salida:");
			vsalida = tec.nextLine();
			System.out.println("Ciudad de llegada:");
			vllegada = tec.nextLine();

			// Restricción 1: los km de la etapa deben estar entre 100 y 300
			if (vkm < KM_MIN || vkm > KM_MAX) {
				System.out.println("No se puede insertar la etapa: los km deben estar entre " + KM_MIN + " y " + KM_MAX
						+ " (has introducido " + vkm + ")");
				// el finally cierra la conexión igualmente
			}

			// Restricción 2: la suma total de la vuelta con esta etapa no puede superar
			// 1500 km
			// operaciones BD DAO
			else {
				sql = "SELECt SUM(km) FROM etapa";
				pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				rs = pstmt.executeQuery();
				vtotal = 0;
				if (rs.first())
					vtotal = rs.getInt(1);

				if (vtotal + vkm > KM_TOTAL_MAX) {
					System.out.println("No se puede insertar la etapa: la vuelta ya tiene " + vtotal
							+ " km y con esta etapa sumaría " + (vtotal + vkm) + " km (máximo " + KM_TOTAL_MAX + ")");
				} else {

					// Se cumplen las dos restricciones: insertamos la etapa
					sql = "INSERT INTO etapa (netapa, km, salida, llegada) VALUES (?, ?, ?, ?)";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, vnetapa);
					pstmt.setInt(2, vkm);
					pstmt.setString(3, vsalida);
					pstmt.setString(4, vllegada);
					pstmt.executeUpdate();
				}

			}
		} catch (NumberFormatException e) {
			System.out.println("Número de etapa, km y dorsal deben ser números enteros");
		} catch (SQLException e) {
			// p. ej. número de etapa repetido o dorsal que no existe
			System.out.println("Error de base de datos: " + e.getMessage());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Cerramos recursos y conexión
			try {
				if (rs != null && !rs.isClosed())
					rs.close();
				if (pstmt != null && !pstmt.isClosed())
					pstmt.close();
				if (con != null && !con.isClosed())
					con.close();
				System.out.println("Desconectado");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}