package ejercicios;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class Ejer5_ResultSetScroll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Traure al ResulSet la taula ciclista ordenad per edat (nacimiento de más joven a mayor)
	
		Connection con = null; 
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql=null;
		//Realizamos la conexi�n
		try {   
			Properties propiedades = new Properties();  
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado"); 		
		///Obtener el ciclista más joven y más viejo (sin filtrar en la sql)		
		// operaciones BD
			sql="select * from ciclista where"
					+ " nacimiento is not null order by nacimiento asc	";
			pstmt=con.prepareStatement(sql,
				    ResultSet.TYPE_SCROLL_INSENSITIVE,
				    ResultSet.CONCUR_READ_ONLY);		
			rs=pstmt.executeQuery();		
		// mas joves
			rs.last();
			System.out.println(rs.getString("nombre"));
			rs.last();
			//El nom del ciclista més jove
			System.out.println("más joven: " +rs.getString(2)+" "+rs.getDate("nacimiento"));
			//El nom del ciclista més major
			rs.first();
			System.out.println("más mayor: "+ rs.getString(2)+" "+rs.getDate("nacimiento"));	
			// El 6 ciclista de major edat
			rs.first();	
			rs.relative(5);
			rs.absolute(6);
			System.out.println("6 más major:  "+rs.getString("nombre")+" "+rs.getDate("nacimiento"));
			// El 2 más joven
			
			
			rs.last();
			//rs.previous();
			rs.relative(-1);
			System.out.println("2 más joven:  " +rs.getString("nombre")+" "+rs.getDate("nacimiento"));
				
			//El 2 más veterano
			rs.first();
			//rs.next();
			rs.relative(1);
			System.out.println("2 m�s veter�:" +rs.getString("nombre")+" "+rs.getDate("nacimiento"));
					
			// Buscar el ciclista (dorsal)  que en
			//la clasificación de etapas ganadas está el 4 por etapas más ganadas
			
			sql="select dorsal, count(*) from etapa"
					+ " group by dorsal order by count(*) desc";
			
			pstmt=con.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE);

			rs=pstmt.executeQuery();
			rs.absolute(4);
			System.out.println("etapas ganadas " +rs.getInt("dorsal")+
					"  "+rs.getInt(2));
		
			//Mostrar al usuario		
	} catch (SQLException e){
			e.printStackTrace();  
	} catch (FileNotFoundException e) {
			e.printStackTrace();
	}catch (IOException e) {
			e.printStackTrace();
	}catch (Exception e) {
			e.printStackTrace();
	}
	finally{
		//Cerramos la conexi�n
		try{ if(con!=null && !con.isClosed())      
			con.close();      
		System.out.println("Desconectado");          
	} catch(SQLException e)
		{            
			e.printStackTrace();       
		}      
	}
	
		

	}

}
