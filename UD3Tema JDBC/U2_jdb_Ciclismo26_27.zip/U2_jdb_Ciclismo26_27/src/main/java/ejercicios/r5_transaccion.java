package ejercicios;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class r5_transaccion {

	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		String vorigen, vdestino;
		int nciclistas, ncoches, nrepres;

		try {
			Properties propiedades = new Properties();
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado");

			Scanner tec = new Scanner(System.in);
			System.out.println("Equipo que desaparece (absorbido):");
			vorigen = tec.nextLine().trim();
			System.out.println("Equipo que lo absorbe:");
			vdestino = tec.nextLine().trim();

			if (vorigen.equalsIgnoreCase(vdestino)) {
				System.out.println("Los dos equipos deben ser distintos");
				return;
			}

			// Comprobamos que existen los dos equipos
			sql = "SELECT COUNT(*) FROM equipo WHERE nomeq IN (?, ?)";
			pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			pstmt.setString(1, vorigen);
			pstmt.setString(2, vdestino);
			rs = pstmt.executeQuery();
			if (rs.first() && rs.getInt(1) < 2) {
				System.out.println("Alguno de los dos equipos no existe");
				return;
			}
			rs.close();
			pstmt.close();

			// ---------- INICIO DE LA TRANSACCIÓN ----------
			con.setAutoCommit(false);

			// 1. Ciclistas
			sql = "UPDATE ciclista SET nomeq = ? WHERE nomeq = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, vdestino);
			pstmt.setString(2, vorigen);
			nciclistas = pstmt.executeUpdate();
			pstmt.close();
			System.out.println("  Ciclistas traspasados: " + nciclistas);

			// 2. Coches
			sql = "DELETE FROM coche WHERE nomequipo = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, vorigen);
			ncoches = pstmt.executeUpdate();
			pstmt.close();
			System.out.println("  Coches traspasados: " + ncoches);

			// 3. Representante (nom_eq es UNIQUE: falla si el destino ya tiene uno)
			sql = "DELETE FROM representante WHERE nom_eq = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, vorigen);
			nrepres = pstmt.executeUpdate();
			pstmt.close();
			System.out.println("  Representantes traspasados: " + nrepres);

			// 4. Borramos el equipo absorbido
			sql = "DELETE FROM equipo WHERE nomeq = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, vorigen);
			pstmt.executeUpdate();

			con.commit();
			// ---------- FIN DE LA TRANSACCIÓN ----------
			System.out.println("Fusión completada: " + vorigen + " ya forma parte de " + vdestino);

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error de base de datos: " + e.getMessage());
			try {
				if (con != null && !con.getAutoCommit()) {
					con.rollback();
					System.out.println("ROLLBACK: se han deshecho todos los cambios, no se ha fusionado nada");
				}
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null && !rs.isClosed())
					rs.close();
				if (pstmt != null && !pstmt.isClosed())
					pstmt.close();
				if (con != null && !con.isClosed()) {
					con.setAutoCommit(true); // dejamos la conexión como estaba (vuelve al pool)
					con.close();
				}
				System.out.println("Desconectado");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
