package ejercicios;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class Ejer1a_Select_while_restriccion2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Integer vnetapa,vcont;
		
		// Realizamos la conexin
		try {
			Properties propiedades = new Properties();
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado");
			// Obtener cuantos ciclistas tiene el equipo que introduzca el usuario
			// Interfaz datos de entrada
			Scanner tec = new Scanner(System.in);
			System.out.println("Introduce en numero de etapa:");
			vnetapa = tec.nextInt();
			
			//c leemos la altura, comprobamos la altura y calculamos la categoria 
			//guardamos la categora en vcategoria
			
			tec.nextLine();	
			// operaciones BD DAO
			sql = " Select * from etapa where netapa=?";
			// Crear PreparedStament		
			pstmt = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
				    ResultSet.CONCUR_READ_ONLY);
			pstmt.setInt(1, vnetapa);
			rs = pstmt.executeQuery();
			if (rs.first()) {	
				sql = " Select count(*) from puerto where netapa=?";
				pstmt = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
					    ResultSet.CONCUR_READ_ONLY);
				pstmt.setInt(1, vnetapa);
				rs = pstmt.executeQuery();
				if (rs.first()) {	
					 vcont=rs.getInt(1);
					if (vcont<2)
					{//si tiene menos de dos hacer el insert
					sql="insert into puerto (nompuerto,altura,pendiente,netapa,categoria) values(?,?,?,?,?)";
					pstmt = con.prepareStatement(sql);
					
					pstmt.setString(1,"puerto1");
					pstmt.setInt(2,1130);
					pstmt.setDouble(3,8.0);
					pstmt.setInt(4, vnetapa);
					pstmt.setString(5,"1");		// en el c modificar y en vez 1 se pasa vcategoria calculada	
					pstmt.executeUpdate();
					System.out.println("Se ha insertado el puerto");			
					}
					else System.out.println("la etapa ya tiene 2 puertos");
				} else	System.out.println("la etapa no existe");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Cerramos la conexi�n
			try {
				if (con != null && !con.isClosed())
					con.close();
				System.out.println("Desconectado");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
