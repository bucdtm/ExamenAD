package ejercicios;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class exem02_actualizar_representante {

	private static String vtip;
	private static String vdni;

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
				//REalitzem la conexi
				Connection con = null; 
				PreparedStatement pstmt = null;
				Integer result;
				String sql;
				String vnomeq;
				Integer vid;
				//Modificar el equipo de un representante, al usurio le pides el id del representante
				//y el nuevo equipo
				
				//lectura de parmetros del usuario
				Scanner tec=new Scanner (System.in);
				System.out.println("nomeq nuevo equipo:");
				vnomeq=tec.nextLine();
				System.out.println("id representante:");
				vid=tec.nextInt();
				tec.nextLine();
				
				try {   
					Properties propiedades = new Properties();  
					propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));					
					DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
					con = ds.getConnection();
					System.out.println("Conectado"); 
					/* Insetatr un nuevo directo con los valores que me de el usuario nombre, telf, dni*/
					
					sql="update representante set nom_eq=? where id=?";
					pstmt=con.prepareStatement(sql);					
					pstmt.setString(1,vnomeq );
					pstmt.setInt(2,vid);													
					pstmt.executeUpdate();

			} catch (SQLException e){
					e.printStackTrace();  
			} catch (FileNotFoundException e) {
					e.printStackTrace();
			}catch (IOException e) {
					e.printStackTrace();
			}catch (Exception e) {
					e.printStackTrace();
			}
			finally{
				//Cerramos la conexi�n
				try{ if(con!=null && !con.isClosed())      
					con.close();      
				System.out.println("Desconectado");          
			} catch(SQLException e)
				{            
					e.printStackTrace();       
				}      
			}
			}			

}
