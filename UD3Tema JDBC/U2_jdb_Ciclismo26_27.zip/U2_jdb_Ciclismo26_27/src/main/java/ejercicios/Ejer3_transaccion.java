package ejercicios;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class Ejer3_transaccion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//REalitzem la conexi�
		Connection con = null; 
		PreparedStatement pstmt = null;
		Integer result;
		String sql;
		String vnombre,vnombre_eq=null;
		Integer vid;
		
		//lectura de director
		System.out.println("Dades del representant"); 
		Scanner tec=new Scanner (System.in);
		System.out.println("nomb:");
		vnombre=tec.nextLine();
		System.out.println("id:");
		vid=tec.nextInt();	
		vnombre=tec.nextLine();
		System.out.println("--Dades del equip--"); 
		System.out.println("nom de l'equip:");
		vnombre_eq=tec.nextLine();			
		try {   
			Properties propiedades = new Properties();  
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo.txt"));
			
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			System.out.println("Conectado"); 
			
			con.setAutoCommit(false);

			sql="insert into equipo (nomeq) values(?)";
			pstmt=con.prepareStatement(sql);	
			pstmt.setString(1,vnombre_eq );
			pstmt.executeUpdate();
			/* Insetatr un nuevo representantes con los valores que me de el usuario nombre,equipo*/
		//Comiena la transacción, la BD ya no hace commit	
			//Primera operación transacción
			sql="insert into representante values(?,?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,vid );
			pstmt.setString(2,vnombre);
			pstmt.setString(3,vnombre_eq );
			pstmt.executeUpdate();
			//Segunda operación transacción
		
			//Termina la transacción hago definitivos los cambios en la BD con comit
			con.commit();
			//Devuelvo el control de las transcciones a la BD
			con.setAutoCommit(true);

	} catch (SQLException e){
			System.out.println("Code: " + e.getErrorCode());
			System.out.println("sqlState: " + e.getSQLState());
			System.out.println("Error Message: " + e.getMessage());
			e.printStackTrace();  		
			try {
				//Deshacer los cambios
				con.rollback();
				con.setAutoCommit(true);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	} catch (FileNotFoundException e) {
			e.printStackTrace();
	}catch (IOException e) {
			e.printStackTrace();
	}catch (Exception e) {
			e.printStackTrace();
	}
	finally{
		//Cerramos la conexi�n
		try{ if(con!=null && !con.isClosed())      
			con.close();      
		System.out.println("Desconectado");          
	} catch(SQLException e)
		{            
			e.printStackTrace();       
		}      
	}
	}			
	
}
