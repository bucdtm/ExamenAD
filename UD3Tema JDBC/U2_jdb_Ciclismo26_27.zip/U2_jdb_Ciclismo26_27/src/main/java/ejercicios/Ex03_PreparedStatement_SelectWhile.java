package ejercicios;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSourceFactory;

public class Ex03_PreparedStatement_SelectWhile {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con = null; 
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		String sql=null;
		//Realizamos la conexi�n
		try {   
			Properties propiedades = new Properties();  
			propiedades.load(new FileInputStream("Configuracion\\PropiedadesCiclismo"));
			DataSource ds = BasicDataSourceFactory.createDataSource(propiedades);
			con = ds.getConnection();
			// operaciones BD
			sql=" Select * from equipo";
		// Crear PreparedStament
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
		//Recuperar la informaci�n en el resultSet varias filas
			while(rs.next())
			{//Mostrar al usuario
				System.out.println(rs.getString(1) +"   "+rs.getString("nomeq"));
			}					
	} catch (SQLException e){
			e.printStackTrace();  
	} catch (FileNotFoundException e) {
			e.printStackTrace();
	}catch (IOException e) {
			e.printStackTrace();
	}catch (Exception e) {
			e.printStackTrace();
	}
	finally{
		//Cerramos la conexi�n
		try{ if(con!=null && !con.isClosed())      
			con.close();      
		System.out.println("Desconectado");          
	} catch(SQLException e)
		{            
			e.printStackTrace();       
		}      
	}
	}


}
